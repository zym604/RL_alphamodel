tqdm_config = {
    'dynamic_ncols': True,
    'ascii': True,
}
