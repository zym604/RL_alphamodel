from tianshou.utils.config import tqdm_config
from tianshou.utils.moving_average import MovAvg

__all__ = [
    'MovAvg',
    'tqdm_config',
]
