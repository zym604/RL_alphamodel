Result of Ant-v2:

![](/docs/_static/images/Ant-v2.png)