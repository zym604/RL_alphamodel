Grid Search on NNI
===

## Grid Search

Grid Search performs an exhaustive searching through a manually specified subset of the hyperparameter space defined in the searchspace file. 

Note that the only acceptable types of search space are `choice`, `quniform`, `randint`. 