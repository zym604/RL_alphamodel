Builtin-Assessors
=================

..  toctree::
    :maxdepth: 1

    Overview<./Assessor/BuiltinAssessor>
    Medianstop<./Assessor/MedianstopAssessor>
    Curvefitting<./Assessor/CurvefittingAssessor>