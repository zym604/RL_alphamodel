# Grid Search

## Grid Search（遍历搜索）

Grid Search 会穷举定义在搜索空间文件中的所有超参组合。

注意，搜索空间仅支持 `choice`, `quniform`, `randint`。