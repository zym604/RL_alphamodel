######################
教程
######################

..  toctree::
    :maxdepth: 2

    安装<Tutorial/Installation>
    实现 Trial<./TrialExample/Trials>
    Tuner<tuners>
    Assessor<assessors>
    NAS (Beta) <nas>
    模型压缩 (Beta) <model_compression>
    特征工程 (Beta) <feature_engineering>
    Web 界面<Tutorial/WebUI>
    训练平台<training_services>
    如何使用 Docker<Tutorial/HowToUseDocker>
    高级功能<advanced>
    如何调试<Tutorial/HowToDebug>
    Windows 中使用 NNI<Tutorial/NniOnWindows>