特征工程
===================

很高兴的宣布 NNI 的特征工程包 Alpha 版本发布了。
其仍处于试验阶段，会根据使用反馈来演化。
诚挚邀请您使用、反馈，或更多贡献。

详细信息，参考以下教程：

..  toctree::
    :maxdepth: 2

    概述 <FeatureEngineering/Overview>
    GradientFeatureSelector <FeatureEngineering/GradientFeatureSelector>
    GBDTSelector <FeatureEngineering/GBDTSelector>
