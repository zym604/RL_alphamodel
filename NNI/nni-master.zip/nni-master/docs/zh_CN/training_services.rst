NNI 支持的训练平台介绍
=====================================

..  toctree::
    概述 <./TrainingService/SupportTrainingService>
    本机<./TrainingService/LocalMode>
    远程<./TrainingService/RemoteMachineMode>
    OpenPAI<./TrainingService/PaiMode>
    OpenPAI Yarn 模式<./TrainingService/PaiYarnMode>
    Kubeflow<./TrainingService/KubeflowMode>
    FrameworkController<./TrainingService/FrameworkControllerMode>
