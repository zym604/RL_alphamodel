######################
示例
######################

..  toctree::
    :maxdepth: 2

    MNIST<./TrialExample/MnistExamples>
    Cifar10<./TrialExample/Cifar10Examples>
    Scikit-learn<./TrialExample/SklearnExamples>
    EvolutionSQuAD<./TrialExample/SquadEvolutionExamples>
    GBDT<./TrialExample/GbdtExample>
    RocksDB <./TrialExample/RocksdbExamples>
    KD 示例 <./TrialExample/KDExample>
    EfficientNet <./TrialExample/EfficientNet>
