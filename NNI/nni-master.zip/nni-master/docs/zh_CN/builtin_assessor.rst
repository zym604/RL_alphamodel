内置 Assessor
=================

..  toctree::
    :maxdepth: 1

    概述<./Assessor/BuiltinAssessor>
    Medianstop<./Assessor/MedianstopAssessor>
    Curvefitting（曲线拟合）<./Assessor/CurvefittingAssessor>