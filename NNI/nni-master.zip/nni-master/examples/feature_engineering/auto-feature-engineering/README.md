 **Automatic Feature Engineering in nni**	
 ===	
 
  Now we have an [example](https://github.com/SpongebBob/tabular_automl_NNI), which could automaticlly do feature engineering in nni. 
  
  These code come from our contributors. And thanks our lovely contributors!
  
 And welcome more and more people to join us!
