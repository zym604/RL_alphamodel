# 在 NNI 中运行神经网络架构搜索

参考 [NNI-NAS-Example](https://github.com/Crysple/NNI-NAS-Example)，来使用贡献者提供的 NAS 接口。

此目录中包含了 Trial 代码，并提供了示例的配置文件来展示如何使用 PPO Tuner 来调优此 Trial 代码。

运行下列代码来准备数据集 `cd data && . download.sh`.

感谢可爱的志愿者，欢迎更多的人加入我们！