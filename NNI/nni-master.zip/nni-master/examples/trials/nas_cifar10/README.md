# Run Neural Architecture Search in NNI
 
Now we have an NAS example [NNI-NAS-Example](https://github.com/Crysple/NNI-NAS-Example) run in NNI using NAS interface from our contributors.	

We have included its trial code in this folder, and provided example config files to show how to use PPO tuner to tune the trial code.

To prepare for the dataset, please run `cd data && . download.sh`.

Thanks our lovely contributors, and welcome more and more people to join us!

