[Documentation](https://nni.readthedocs.io/en/latest/TrialExample/EfficientNet.html)
