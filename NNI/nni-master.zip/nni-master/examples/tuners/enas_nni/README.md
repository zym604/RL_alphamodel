 **Run ENAS in NNI**	
 ===	
 
  Now we have an enas example [enas-nni](https://github.com/countif/enas_nni) run in NNI from our contributors.	
 Thanks our lovely contributors. 	
 And welcome more and more people to join us!
