**在 NNI 中运行 ENAS**  
===

来自贡献者的 [enas-nni](https://github.com/countif/enas_nni) 可运行在 NNI 中。 非常感谢！  
欢迎更多志愿者加入我们！