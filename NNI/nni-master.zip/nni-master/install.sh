#!/bin/bash
make easy-install
